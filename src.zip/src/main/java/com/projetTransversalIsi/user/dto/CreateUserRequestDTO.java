package com.projetTransversalIsi.user.dto;

import com.projetTransversalIsi.user.profil.application.ProfilCreationDTO;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.Set;

public record CreateUserRequestDTO(
        @NotBlank @Email String email,
        @NotBlank String idRole, 
        @NotEmpty Set<String> idPermissions,
        @Valid ProfilCreationDTO profile) {
}
