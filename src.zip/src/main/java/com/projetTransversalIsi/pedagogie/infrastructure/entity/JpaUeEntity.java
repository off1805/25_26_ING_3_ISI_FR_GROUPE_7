package com.projetTransversalIsi.pedagogie.infrastructure.entity;

import com.projetTransversalIsi.user.profil.infrastructure.JpaTeacherProfileEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Getter
@Setter
@Table(name = "ue")
public class JpaUeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String libelle;

    @Column(nullable = false, unique = true)
    private String code;

    @Column(nullable = false)
    private int credit;

    @Column(nullable = false)
    private int volumeHoraireTotal;

    private String description;

    @Column(name = "specialite_id")
    private Long specialiteId;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "ue_enseignant",
        joinColumns = @JoinColumn(name = "ue_id"),
        inverseJoinColumns = @JoinColumn(name = "enseignant_id")
    )
    private Set<JpaTeacherProfileEntity> enseignants = new HashSet<>();

    @Column(nullable = false, columnDefinition = "varchar(255) default '#ffffff'")
    private String couleur = "#ffffff";

    @Column(name = "semestre")
    private Integer semestre; // 1 or 2

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;

    @Column(name = "is_deleted", nullable = false)
    private Boolean isDeleted = false;

    @PrePersist
    public void applyDefaults() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (isDeleted == null) {
            isDeleted = false;
        }
    }
}
