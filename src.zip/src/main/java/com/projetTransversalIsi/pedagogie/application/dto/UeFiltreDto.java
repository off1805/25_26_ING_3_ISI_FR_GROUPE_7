package com.projetTransversalIsi.pedagogie.application.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UeFiltreDto {
    private String libelle;
    private String code;
    private Long specialiteId;
    private Boolean deleted = false;
}
